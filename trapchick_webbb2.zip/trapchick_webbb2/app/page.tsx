"use client";

import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase";

type Album = { id: string; title: string; artist_name: string; description: string | null; artwork_key: string | null; release_date: string | null };
type Upcoming = { id: string; title: string; artist_name: string; release_type: string; description: string | null; release_at: string | null };
type Review = { id: string; rating: number; comment: string | null; created_at: string; albums: { title: string; artist_name: string } | null };
type PublicProfile = { id: string; nickname: string | null; bio: string | null; avatar_key: string | null };

const DEFAULT_AVATAR = "/default-avatar.png";

export default function Home() {
  const [tab, setTab] = useState<"music" | "soon" | "profile" | "friends">("music");
  const [albums, setAlbums] = useState<Album[]>([]);
  const [upcoming, setUpcoming] = useState<Upcoming[]>([]);
  const [email, setEmail] = useState("");
  const [nickname, setNickname] = useState("");
  const [password, setPassword] = useState("");
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [profileName, setProfileName] = useState("Слушатель");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState(DEFAULT_AVATAR);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [profileTab, setProfileTab] = useState<"inventory" | "ratings">("inventory");
  const [authMode, setAuthMode] = useState<"register" | "login">("register");
  const [editing, setEditing] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [welcomeOpen, setWelcomeOpen] = useState(false);
  const [emailConfirmOpen, setEmailConfirmOpen] = useState(false);
  const [peopleQuery, setPeopleQuery] = useState("");
  const [people, setPeople] = useState<PublicProfile[]>([]);
  const [selectedPerson, setSelectedPerson] = useState<PublicProfile | null>(null);
  const [following, setFollowing] = useState(false);
  const [ownFollowCounts, setOwnFollowCounts] = useState({ followers: 0, following: 0 });
  const [viewedFollowCounts, setViewedFollowCounts] = useState({ followers: 0, following: 0 });
  const [followListLoading, setFollowListLoading] = useState(false);
  const [peopleLoading, setPeopleLoading] = useState(false);
  const [followList, setFollowList] = useState<PublicProfile[]>([]);
  const [followListMode, setFollowListMode] = useState<"followers" | "following" | null>(null);

  const supabase = useMemo(() => { try { return supabaseBrowser(); } catch { return null; } }, []);

  async function loadProfile(id: string) {
    if (!supabase) return;
    const { data: p } = await supabase.from("profiles").select("nickname,bio,avatar_key,status").eq("id", id).maybeSingle();
    if (p?.status === "blocked") {
      await supabase.auth.signOut(); setUserEmail(null); setUserId(null); setMessage("Этот аккаунт заблокирован администратором."); return;
    }
    if (p) {
      setProfileName(p.nickname || "Слушатель"); setNickname(p.nickname || "Слушатель");
      setBio(p.bio || ""); setAvatarUrl(p.avatar_key || DEFAULT_AVATAR);
    }
    const { data: rows } = await supabase.from("album_reviews")
      .select("id,rating,comment,created_at,albums(title,artist_name)")
      .eq("user_id", id).order("created_at", { ascending: false });
    setReviews((rows ?? []) as unknown as Review[]);
    await refreshFollowCounts(id, "own");
  }

  useEffect(() => {
    if (!supabase) { setMessage("Подключи Supabase: заполни .env.local по инструкции."); return; }
    let alive = true;
    supabase.auth.getUser().then(async ({ data }) => {
      if (!alive) return;
      if (!data.user) { setWelcomeOpen(true); return; }
      setUserEmail(data.user.email ?? null); setUserId(data.user.id); await loadProfile(data.user.id);
    });
    supabase.from("albums").select("id,title,artist_name,description,artwork_key,release_date")
      .eq("status", "published").order("release_date", { ascending: false }).then(({ data, error }) => {
        if (!alive) return; if (error) setMessage("Не удалось загрузить каталог. Проверь политики доступа и подключение."); setAlbums((data ?? []) as Album[]);
      });
    supabase.from("upcoming_releases").select("id,title,artist_name,release_type,description,release_at")
      .eq("status", "published").order("release_at", { ascending: true }).then(({ data }) => { if (alive) setUpcoming((data ?? []) as Upcoming[]); });
    return () => { alive = false; };
  }, [supabase]);

  async function refreshFollowCounts(id: string, target: "own" | "viewed" = "own") {
    if (!supabase) return;
    const [followersResult, followingResult] = await Promise.all([
      supabase.from("user_follows").select("follower_id", { count: "exact", head: true }).eq("following_id", id),
      supabase.from("user_follows").select("following_id", { count: "exact", head: true }).eq("follower_id", id),
    ]);
    const error = followersResult.error || followingResult.error;
    if (error) { setMessage(`Не удалось обновить счётчики подписок: ${error.message}`); return; }
    const counts = { followers: followersResult.count ?? 0, following: followingResult.count ?? 0 };
    if (target === "own") setOwnFollowCounts(counts); else setViewedFollowCounts(counts);
  }

  async function searchPeople(value: string) {
    setPeopleQuery(value);
    if (!supabase || !userId || value.trim().length < 2) { setPeople([]); return; }
    setPeopleLoading(true);
    const { data, error } = await supabase.from("profiles").select("id,nickname,bio,avatar_key")
      .ilike("nickname", `%${value.trim()}%`).neq("id", userId).order("nickname", { ascending: true }).limit(20);
    setPeopleLoading(false);
    if (error) { setMessage(`Не удалось найти пользователей: ${error.message}`); return; }
    setPeople((data ?? []) as PublicProfile[]);
  }

  async function openPerson(person: PublicProfile) {
    if (!supabase || !userId) return;
    setSelectedPerson(person); setFollowListMode(null); setFollowList([]);
    const { data, error } = await supabase.from("user_follows").select("follower_id").eq("follower_id", userId).eq("following_id", person.id).maybeSingle();
    if (error) { setMessage(`Не удалось проверить подписку: ${error.message}`); setFollowing(false); }
    else setFollowing(!!data);
    await refreshFollowCounts(person.id, "viewed");
  }

  async function toggleFollow() {
    if (!supabase || !userId || !selectedPerson || selectedPerson.id === userId) return;
    setBusy(true);
    const wasFollowing = following;
    const result = wasFollowing
      ? await supabase.from("user_follows").delete().eq("follower_id", userId).eq("following_id", selectedPerson.id)
      : await supabase.from("user_follows").upsert({ follower_id: userId, following_id: selectedPerson.id }, { onConflict: "follower_id,following_id", ignoreDuplicates: true });
    if (result.error) { setBusy(false); setMessage(`Не удалось изменить подписку: ${result.error.message}`); return; }
    const { data: check, error: checkError } = await supabase.from("user_follows").select("follower_id").eq("follower_id", userId).eq("following_id", selectedPerson.id).maybeSingle();
    setBusy(false);
    if (checkError) { setMessage(`Изменение отправлено, но не удалось проверить результат: ${checkError.message}`); return; }
    const nowFollowing = !!check;
    setFollowing(nowFollowing);
    if (nowFollowing === wasFollowing) { setMessage(wasFollowing ? "Не удалось отписаться. Проверь права доступа к user_follows." : "Подписка не сохранилась. Проверь SQL-миграцию и права доступа."); return; }
    setMessage(nowFollowing ? `Ты подписался на ${selectedPerson.nickname || "пользователя"}.` : "Ты отписался от пользователя.");
    await refreshFollowCounts(selectedPerson.id, "viewed");
    await refreshFollowCounts(userId, "own");
  }

  async function showFollowList(mode: "followers" | "following") {
    if (!supabase || !userId) return;
    setFollowListMode(mode);
    setFollowListLoading(true);
    const column = mode === "followers" ? "follower_id" : "following_id";
    const matchColumn = mode === "followers" ? "following_id" : "follower_id";
    const { data, error } = await supabase.from("user_follows").select(column).eq(matchColumn, userId).limit(100);
    if (error) { setFollowListLoading(false); setMessage(`Не удалось загрузить список: ${error.message}`); return; }
    const ids = (data ?? []).map((row: any) => row[column]).filter(Boolean);
    if (!ids.length) { setFollowList([]); setFollowListLoading(false); return; }
    const { data: profiles, error: profileError } = await supabase.from("profiles").select("id,nickname,bio,avatar_key").in("id", ids);
    setFollowListLoading(false);
    if (profileError) { setMessage(`Не удалось загрузить профили: ${profileError.message}`); return; }
    const byId = new Map((profiles ?? []).map((profile: PublicProfile) => [profile.id, profile]));
    setFollowList(ids.map((id: string) => byId.get(id)).filter(Boolean) as PublicProfile[]);
  }

  async function signUp(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!supabase) return; setBusy(true); setMessage("");
    const { error } = await supabase.auth.signUp({ email, password, options: { data: { nickname }, emailRedirectTo: `${window.location.origin}/` } });
    setBusy(false);
    if (error) setMessage(error.message);
    else { setMessage(""); setEmailConfirmOpen(true); }
  }

  async function signIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!supabase) return; setBusy(true); setMessage("");
    const { data, error } = await supabase.auth.signInWithPassword({ email, password }); setBusy(false);
    if (error) { setMessage(error.message); return; }
    setUserEmail(data.user.email ?? email); setUserId(data.user.id); await loadProfile(data.user.id); setMessage("Ты вошёл в Трапчик.мп3.");
  }

  async function saveProfile() {
    if (!supabase || !userId) return; setBusy(true); setMessage("");
    const { error } = await supabase.from("profiles").update({ nickname: profileName.trim() || "Слушатель", bio: bio.trim() }).eq("id", userId);
    setBusy(false); if (error) setMessage(`Не удалось сохранить профиль: ${error.message}`); else { setNickname(profileName); setEditing(false); setMessage("Профиль сохранён."); }
  }

  async function uploadAvatar(file?: File) {
    if (!supabase || !userId || !file) return;
    if (!file.type.startsWith("image/")) { setMessage("Выбери файл изображения."); return; }
    if (file.size > 5 * 1024 * 1024) { setMessage("Изображение должно быть не больше 5 МБ."); return; }
    setBusy(true); setMessage("");
    const path = `${userId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const { error: uploadError } = await supabase.storage.from("avatars").upload(path, file, { upsert: true, contentType: file.type });
    if (uploadError) { setBusy(false); setMessage(`Не удалось загрузить аватарку: ${uploadError.message}`); return; }
    const { data } = supabase.storage.from("avatars").getPublicUrl(path);
    const { error } = await supabase.from("profiles").update({ avatar_key: data.publicUrl }).eq("id", userId);
    setBusy(false); if (error) setMessage(`Аватар загружен, но профиль не обновился: ${error.message}`); else { setAvatarUrl(data.publicUrl); setMessage("Аватарка обновлена."); }
  }

  async function signOut() {
    if (!supabase) return; await supabase.auth.signOut(); setUserEmail(null); setUserId(null); setProfileName("Слушатель"); setBio(""); setAvatarUrl(DEFAULT_AVATAR); setReviews([]); setMessage("Ты вышел из аккаунта.");
  }

  const filtered = albums.filter(a => `${a.title} ${a.artist_name}`.toLowerCase().includes(search.toLowerCase()));

  return <main className="shell">
    <header className="topbar">
      <button className="menuToggle" type="button" aria-label={menuOpen ? "Закрыть меню" : "Открыть меню"} aria-expanded={menuOpen} onClick={() => setMenuOpen(v => !v)}>
        <span/><span/><span/>
      </button>
      <a className="brand" href="#"><span className="brandMark">Т</span><span>ТРАПЧИК<span className="brandDot">.МР3</span></span></a>
      <span className="online">{userEmail ? "● В сети" : "● Гость"}</span>
    </header>

    {menuOpen && <button type="button" className="menuBackdrop" aria-label="Закрыть меню" onClick={() => setMenuOpen(false)} />}
    <aside className={menuOpen ? "sideMenu open" : "sideMenu"} aria-hidden={!menuOpen} inert={!menuOpen}>
      <div className="sideMenuHead"><span className="eyebrow">НАВИГАЦИЯ</span><button type="button" className="menuClose" aria-label="Закрыть меню" onClick={() => setMenuOpen(false)}>×</button></div>
      <button type="button" className={tab === "music" ? "sideNav active" : "sideNav"} onClick={() => { setTab("music"); setMenuOpen(false); }}><span>♫</span> Музыка</button>
      <button type="button" className={tab === "soon" ? "sideNav active" : "sideNav"} onClick={() => { setTab("soon"); setMenuOpen(false); }}><span>◷</span> Скоро</button>
      <button type="button" className={tab === "profile" ? "sideNav active" : "sideNav"} onClick={() => { setTab("profile"); setMenuOpen(false); }}><span>◎</span> Профиль</button>
      <button type="button" className={tab === "friends" ? "sideNav active" : "sideNav"} onClick={() => { setTab("friends"); setMenuOpen(false); }}><span>⌕</span> Поиск друзей</button>
      <div className="sideMenuFoot">ТРАПЧИК.МР3</div>
    </aside>

    {(tab === "music" || tab === "soon") && <section className="hero">
      <div className="heroText"><div className="eyebrow">ТВОЯ МУЗЫКА. ТВОИ ПРАВИЛА.</div><h1>Здесь звучит<br/><em>Трапчик.мп3</em></h1><p>Релизы, которые хочется переслушивать. Без лишнего шума — только музыка.</p><button className="primary" onClick={() => setTab("music")}>Открыть каталог <span>↗</span></button></div>
      <div className="heroArt" aria-hidden="true"><div className="orb orbOne"/><div className="orb orbTwo"/><div className="heroGlyph">Т<span>.</span></div><div className="heroCaption">INDEPENDENT SOUND<br/>EST. 2026</div></div>
    </section>}

    {message && <div className="notice">{message}</div>}

    {welcomeOpen && !userEmail && <div className="modalBackdrop" role="presentation">
      <section className="appModal welcomeModal" role="dialog" aria-modal="true" aria-labelledby="welcomeTitle">
        <div className="modalEyebrow">ТРАПЧИК.МР3</div>
        <h2 id="welcomeTitle">Шарррррраут!</h2>
        <p>Чтобы перейти на сайт и слушать жесткий трапчик, зарегистрируйся или войди в уже существующий аккаунт!</p>
        <div className="modalActions">
          <button className="secondary" type="button" onClick={() => { setAuthMode("login"); setTab("profile"); setWelcomeOpen(false); setMessage(""); }}>Войти</button>
          <button className="primary" type="button" onClick={() => { setAuthMode("register"); setTab("profile"); setWelcomeOpen(false); setMessage(""); }}>Зарегистрироваться</button>
        </div>
      </section>
    </div>}

    {emailConfirmOpen && <div className="modalBackdrop" role="presentation">
      <section className="appModal" role="dialog" aria-modal="true" aria-labelledby="emailConfirmTitle">
        <div className="modalEyebrow">ПОЧТИ ГОТОВО</div>
        <h2 id="emailConfirmTitle">Ещё чуть-чуть!</h2>
        <p>Осталось подтвердить почту, шараут на нее уже отправлен!</p>
        <div className="modalActions singleAction"><button className="primary" type="button" onClick={() => setEmailConfirmOpen(false)}>Ок</button></div>
      </section>
    </div>}

    {tab === "music" && <section className="section"><div className="sectionHead"><div><div className="eyebrow">БИБЛИОТЕКА</div><h2>Каталог музыки</h2></div><input className="search" placeholder="Поиск релиза..." value={search} onChange={e => setSearch(e.target.value)}/></div>
      {filtered.length ? <div className="albumGrid">{filtered.map((a, i) => <article className="album" key={a.id}><div className={`cover cover${i % 4}`}><span>Т.МР3</span><b>{a.title.slice(0,1).toUpperCase()}</b></div><div className="albumInfo"><h3>{a.title}</h3><p>{a.artist_name}</p>{a.release_date && <small>{new Date(a.release_date).toLocaleDateString("ru-RU")}</small>}</div></article>)}</div> : <div className="empty"><div className="emptyIcon">♫</div><h3>Пока здесь тихо</h3><p>Опубликованные альбомы появятся здесь, когда администратор добавит музыку.</p></div>}
    </section>}

    {tab === "soon" && <section className="section"><div className="sectionHead"><div><div className="eyebrow">НА ГОРИЗОНТЕ</div><h2>Скоро</h2></div></div>
      {upcoming.length ? <div className="soonList">{upcoming.map((r, i) => <article className="soonCard" key={r.id}><div className={`soonCover cover${i%4}`}>SOON</div><div><span className="tag">{r.release_type === "single" ? "Сингл" : r.release_type === "ep" ? "EP" : "Альбом"}</span><h3>{r.title}</h3><p>{r.artist_name}</p>{r.description && <p className="muted">{r.description}</p>}</div><div className="releaseDate">{r.release_at ? new Date(r.release_at).toLocaleDateString("ru-RU") : "Дата уточняется"}</div></article>)}</div> : <div className="empty"><div className="emptyIcon">◷</div><h3>Готовим новые релизы</h3><p>Анонсы с датами выхода и превью появятся здесь.</p></div>}
    </section>}

    {tab === "friends" && <section className="section friendsSection">
      <div className="friendsHeader"><div className="eyebrow">СООБЩЕСТВО ТРАПЧИКА</div><h2>Поиск друзей</h2><p>Находи слушателей, смотри их профили и подписывайся.</p></div>
      {!userEmail ? <div className="empty"><h3>Войди, чтобы искать друзей</h3><button className="primary" onClick={() => { setTab("profile"); setAuthMode("login"); }}>Войти в аккаунт</button></div> : <>
        <div className="friendsSearch"><span>⌕</span><input aria-label="Поиск пользователей" value={peopleQuery} onChange={e => searchPeople(e.target.value)} placeholder="Поиск по никнейму..."/><button type="button" onClick={() => { setPeopleQuery(""); setPeople([]); }}>Очистить</button></div>
        <div className="friendsResults">{peopleLoading ? <p className="muted">Ищем пользователей…</p> : peopleQuery.trim().length < 2 ? <p className="muted">Введи минимум 2 символа, чтобы начать поиск.</p> : people.length ? people.map(person => <button className="friendCard" type="button" key={person.id} onClick={() => openPerson(person)}><img src={person.avatar_key || DEFAULT_AVATAR} alt=""/><span className="friendCardText"><b>{person.nickname || "Слушатель"}</b><small>{person.bio || "Профиль слушателя Трапчик.мр3"}</small></span><span className="friendArrow">Открыть профиль →</span></button>) : <p className="muted">Никого не нашли. Проверь написание никнейма.</p>}</div>
        {selectedPerson && <div className="publicProfileCard"><button className="backLink" type="button" onClick={() => setSelectedPerson(null)}>← Назад к поиску</button><img className="publicAvatar" src={selectedPerson.avatar_key || DEFAULT_AVATAR} alt=""/><h3>{selectedPerson.nickname || "Слушатель"}</h3><p>{selectedPerson.bio || "Пока без описания"}</p><div className="publicProfileStats"><div><b>{viewedFollowCounts.followers}</b><span>Подписчиков</span></div><div><b>{viewedFollowCounts.following}</b><span>Подписок</span></div></div><button className="primary followAction" type="button" disabled={busy} onClick={toggleFollow}>{busy ? "Секунду…" : following ? "Отписаться" : "Подписаться"}</button></div>}
      </>}
    </section>}

    {tab === "profile" && <section className="section profileSection">
      {!userEmail ? <div className="authWrap"><div className="eyebrow">АККАУНТ ТРАПЧИК.МР3</div><h2>{authMode === "register" ? "Создать аккаунт" : "С возвращением"}</h2>
        {authMode === "register" ? <form className="authCard authSingle" onSubmit={signUp}><label>Никнейм<input required maxLength={40} value={nickname} onChange={e => setNickname(e.target.value)} placeholder="Как тебя показывать?"/></label><label>Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.com"/></label><label>Пароль<div className="passwordField"><input type={showPassword ? "text" : "password"} required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="Не менее 6 символов"/><button type="button" className="passwordToggle" aria-label={showPassword ? "Скрыть пароль" : "Показать пароль"} aria-pressed={showPassword} onClick={() => setShowPassword(v => !v)}>{showPassword ? "◉" : "◎"}</button></div></label><button className="primary full" disabled={busy}>Зарегистрироваться</button><small>После регистрации нужно подтвердить email по ссылке из письма.</small><p className="authSwitch">Уже есть аккаунт? <button type="button" onClick={() => { setAuthMode("login"); setShowPassword(false); setMessage(""); }}>Войти</button></p></form> : <form className="authCard authSingle" onSubmit={signIn}><label>Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.com"/></label><label>Пароль<div className="passwordField"><input type={showPassword ? "text" : "password"} required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="Пароль"/><button type="button" className="passwordToggle" aria-label={showPassword ? "Скрыть пароль" : "Показать пароль"} aria-pressed={showPassword} onClick={() => setShowPassword(v => !v)}>{showPassword ? "◉" : "◎"}</button></div></label><button className="primary full" disabled={busy}>Войти</button><p className="authSwitch">Нет аккаунта? <button type="button" onClick={() => { setAuthMode("register"); setShowPassword(false); setMessage(""); }}>Зарегистрироваться</button></p></form>}
      </div> : <div className="userProfile">
        <div className="profileIdentity"><div className="avatarFrame"><img src={avatarUrl || DEFAULT_AVATAR} alt="Аватар пользователя" className="profileAvatar"/><label className="avatarChange">Изменить фото<input type="file" accept="image/*" onChange={e => uploadAvatar(e.target.files?.[0])} disabled={busy}/></label></div>
          {editing ? <div className="profileEdit"><label>Никнейм<input value={profileName} maxLength={40} onChange={e => setProfileName(e.target.value)}/></label><label>Описание<textarea value={bio} maxLength={300} onChange={e => setBio(e.target.value)} placeholder="Расскажи немного о себе..."/></label><div className="profileActions"><button className="primary" onClick={saveProfile} disabled={busy}>Сохранить</button><button className="secondary" onClick={() => { setEditing(false); loadProfile(userId!); }}>Отмена</button></div></div> : <><h2 className="profileNickname">{profileName}</h2><p className="profileBio">{bio || ""}</p><button className="secondary editProfile" onClick={() => setEditing(true)}>Редактировать профиль</button><div className="profileFollowNumbers"><button type="button" onClick={() => showFollowList("followers")}><b>{ownFollowCounts.followers}</b><span>Подписчики</span></button><button type="button" onClick={() => showFollowList("following")}><b>{ownFollowCounts.following}</b><span>Подписки</span></button></div></>}
        {followListMode && <div className="followPanel"><div className="followPanelHead"><b>{followListMode === "followers" ? "Подписчики" : "Подписки"}</b><button type="button" onClick={() => setFollowListMode(null)}>Закрыть</button></div>{followListLoading ? <p className="muted">Загружаем список…</p> : followList.length ? followList.map(person => <button className="personRow" type="button" key={person.id} onClick={() => { setTab("friends"); openPerson(person); }}><img src={person.avatar_key || DEFAULT_AVATAR} alt=""/><span>{person.nickname || "Слушатель"}</span><small>Открыть профиль →</small></button>) : <p className="muted">Пока здесь никого нет.</p>}</div>}
        </div>
        <div className="profileTabs"><button className={profileTab === "inventory" ? "profileTab active" : "profileTab"} onClick={() => setProfileTab("inventory")}>Инвентарь</button><button className={profileTab === "ratings" ? "profileTab active" : "profileTab"} onClick={() => setProfileTab("ratings")}>Оценки</button></div>
        {profileTab === "inventory" ? <div className="profileEmpty"><p>Инвентарь пока пуст.</p></div> : reviews.length ? <div className="reviewList">{reviews.map(r => <article className="reviewItem" key={r.id}><div className="reviewTop"><b>{r.albums?.title || "Альбом"}</b><span>★ {r.rating}/10</span></div>{r.albums?.artist_name && <small>{r.albums.artist_name}</small>}{r.comment && <p>{r.comment}</p>}<time>{new Date(r.created_at).toLocaleDateString("ru-RU")}</time></article>)}</div> : <div className="profileEmpty"><p>бро рил еще не оставил ни одного кома бич</p></div>}
        <div className="profileLogout"><button className="secondary" onClick={signOut}>Выйти из аккаунта</button></div>
      </div>}
    </section>}

    <footer><span>ТРАПЧИК.МР3 © 2026</span><span>СДЕЛАНО ДЛЯ МУЗЫКИ</span></footer>
  </main>;
}
